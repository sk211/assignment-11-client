import React from 'react';

const Shiping = () => {
    return (
        <div>
            <h2>This is Shiping</h2>
        </div>
    );
};

export default Shiping;