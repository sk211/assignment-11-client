// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDJxN3z396O-1BudPYMmhl_jClyCfYpt2U",
  authDomain: "new-65-66-module.firebaseapp.com",
  projectId: "new-65-66-module",
  storageBucket: "new-65-66-module.appspot.com",
  messagingSenderId: "1040161545946",
  appId: "1:1040161545946:web:e1de754c35a3f061034fe3"
};

  export default firebaseConfig